DESIGN_CONFIG=./designs/sky130hd/gcd/config.mk make
DESIGN_CONFIG=./designs/sky130hd/ibex/config.mk make
DESIGN_CONFIG=./designs/sky130hd/aes/config.mk make
DESIGN_CONFIG=./designs/sky130hd/jpeg/config.mk make
#
DESIGN_CONFIG=./designs/gf12/gcd/config.mk make
DESIGN_CONFIG=./designs/gf12/ibex/config.mk make
DESIGN_CONFIG=./designs/gf12/aes/config.mk make
DESIGN_CONFIG=./designs/gf12/jpeg/config.mk make
